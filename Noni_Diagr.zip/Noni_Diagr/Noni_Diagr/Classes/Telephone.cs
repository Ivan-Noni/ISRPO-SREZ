﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Noni_Diagr.Classes
{
    internal class Telephone
    {
        public int articul { get; set; }
        public string nameTelephone { get; set; }
        public string category { get; set; }
        public double cost { get; set; }
        public int count { get; set; }
        public string manufacturer { get; set; }
    }
}
