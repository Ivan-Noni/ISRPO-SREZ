﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;
using System.Diagnostics;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using Noni_Diagr.Classes;

namespace Noni_Diagr
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string dStart;
        string dEnd;
        List<Sale> d = new List<Sale>();

        Dictionary<string, double> data = new Dictionary<string, double>();
        public MainWindow()
        {
            InitializeComponent();
            cmbSelectDiagr.Items.Add("Фирмы");
            cmbSelectDiagr.Items.Add("Продажи");
        }

        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            if (dtpStart.SelectedDate == null && dtpEnd.SelectedDate == null)
            {
                MessageBox.Show("Укажите даты");
                return;
            }
            cmbSelectDiagr.IsEnabled = true;
            dStart = $"{dtpStart.SelectedDate.Value.Month.ToString()}.{dtpStart.SelectedDate.Value.Day.ToString()}.{dtpStart.SelectedDate.Value.Year.ToString()}";
            dEnd = $"{dtpEnd.SelectedDate.Value.Month.ToString()}.{dtpEnd.SelectedDate.Value.Day.ToString()}.{dtpEnd.SelectedDate.Value.Year.ToString()}";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(
                $"https://localhost:7100/api/Sale?dateStart={dStart}&dateEnd={dEnd}");
            request.Method = "POST";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream stream = response.GetResponseStream();
            StreamReader sr = new StreamReader(stream);


            var sReadData = sr.ReadToEnd();
            response.Close();


            d = JsonConvert.DeserializeObject<List<Sale>>(sReadData);
            lstTest.ItemsSource = d;

            foreach (var t in d)
            {
                for (int i = 0; i < t.telephones.Count; i++)
                {
                    if (!data.Keys.Contains(t.telephones[i].manufacturer))
                    {
                        data.Add(t.telephones[i].manufacturer, 0);
                    }
                    else continue;
                    data[t.telephones[i].manufacturer] += t.telephones[i].count;
                }
            }
        }

        private void dtpStart_SelectedDateChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            dtpEnd.DisplayDateStart = dtpStart.SelectedDate.Value;
            dtpEnd.IsEnabled = true;
        }

        private void btnCheque_Click(object sender, RoutedEventArgs e)
        {
            if (lstTest.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Выделите запись");
                return;
            }
            var helper = new WordHelper("товарный чек шаблон.doc");
            var items = new Dictionary<string, string>();

            var test = lstTest.SelectedItems[0] as Sale;

            int i = 1;
            double itogSumm = 0;
            foreach (var t in test.telephones)
            {
                items.Add($"<namePhone{i}>", t.nameTelephone);
                items.Add($"<art{i}>", t.articul.ToString());
                items.Add($"<count{i}>", t.count.ToString());
                items.Add($"<cost{i}>", t.cost.ToString());
                items.Add($"<summ{i}>", (t.count * t.cost).ToString());
                itogSumm += t.count * t.cost;
                i++;
            }
            for (int j = i; j < 10; j++)
            {
                items.Add($"<namePhone{j}>", "");
                items.Add($"<art{j}>", "");
                items.Add($"<count{j}>", "");
                items.Add($"<cost{j}>", "");
                items.Add($"<summ{j}>", "");
            }

            items.Add("<nChek>", "1234567890qwerty");
            items.Add("<day>", test.dateSale.Day.ToString());
            items.Add("<mounth>", test.dateSale.Month.ToString());
            items.Add("<year>", test.dateSale.Year.ToString().Substring(0, 2));
            items.Add("<itogSumm>", itogSumm.ToString().PadRight(69 - itogSumm.ToString().Length, '_'));

            helper.Process(items);
        }

        private void btnChequeExcel_Click(object sender, RoutedEventArgs e)
        {
            if (lstTest.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Выделите запись");
                return;
            }

            var test = lstTest.SelectedItems[0] as Sale;

            var application = new Excel.Application();
            application.SheetsInNewWorkbook = 1;

            Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet = application.Worksheets[1];
            worksheet.Name = "Лист1";

            Excel.Range hatSc = worksheet.Range[worksheet.Cells[1][2], worksheet.Cells[6][2]];
            hatSc.Merge();
            hatSc.Value = "(наименование организации, ИНН)";
            hatSc.HorizontalAlignment = Excel.XlVAlign.xlVAlignCenter;
            hatSc.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;
            hatSc.Font.Size = 10;

            Excel.Range hatTh = worksheet.Range[worksheet.Cells[1][3], worksheet.Cells[6][4]];
            hatTh.Merge();
            hatTh.Value = $"Товарный чек № {"1234567890qwerty"} от {test.dateSale.ToString().Substring(0, 10)} г.";
            hatTh.HorizontalAlignment = Excel.XlVAlign.xlVAlignCenter;
            hatTh.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            hatTh.Font.Size = 18;
            hatTh.Font.Bold = true;

            Excel.Range tableHeader = worksheet.Range[worksheet.Cells[1][5], worksheet.Cells[6][5]];
            tableHeader.Font.Size = 18;
            tableHeader.Font.Bold = true;

            Excel.Range table = worksheet.Range[worksheet.Cells[1][5], worksheet.Cells[6][test.telephones.Count() + 5]];
            table.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;

            table.Cells[1][1] = "№ П/П";
            table.Cells[2][1] = "Наименование, характеристика товара";
            table.Cells[3][1] = "Ед";
            table.Cells[4][1] = "Кол-во";
            table.Cells[5][1] = "Цена";
            table.Cells[6][1] = "Сумма";

            int i = 2;
            foreach (var t in test.telephones)
            {
                table.Cells[1][i] = i - 1;
                table.Cells[2][i] = t.nameTelephone;
                table.Cells[3][i] = "Шт";
                table.Cells[4][i] = t.count;
                table.Cells[5][i] = t.cost;
                table.Cells[6][i].Formula = $"=D{i + 4} * E{i + 4}";
                i++;
            }

            worksheet.Cells[5][i + 4] = "Всего";
            worksheet.Cells[6][i + 4].Formula = $"=SUM(F6:F{test.telephones.Count() + 5})";

            table.Columns.AutoFit();

            application.Visible = true;
        }

        private void btnOtchWord_Click(object sender, RoutedEventArgs e)
        {
            Word.Application application = new Word.Application();
            Word.Document document = application.Documents.Add();
            var pText = document.Paragraphs.Add();
            pText.Format.SpaceAfter = 10f;
            pText.Range.Text = $"Отчет по продажам за период от {dtpStart.SelectedDate.Value.Date.ToString().Substring(0, 10)} до {dtpEnd.SelectedDate.Value.Date.ToString().Substring(0, 10)}";
            pText.Range.InsertParagraphAfter();

            var pTable = document.Paragraphs.Add();
            pTable.Format.SpaceAfter = 5;
            pTable.Format.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
            Word.Table tbl = application.ActiveDocument.Tables.Add(pTable.Range, d.Count() + 1, 5, Word.WdDefaultTableBehavior.wdWord9TableBehavior);


            tbl.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
            tbl.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;

            tbl.Cell(1, 1).Range.Text = "Дата продажи";
            tbl.Cell(1, 2).Range.Text = "Клиент";
            tbl.Cell(1, 3).Range.Text = "Количество";
            tbl.Cell(1, 4).Range.Text = "Цена";
            tbl.Cell(1, 5).Range.Text = "Сумма";
            
            int i = 2;
            double countSum = 0; double costSum = 0; double itogSumm = 0;

            foreach (var c in d)
            {
                foreach (var d in c.telephones)
                {
                    countSum += d.count;
                    costSum += d.cost;
                }
                tbl.Cell(i, 1).Range.Text = c.dateSale.ToShortDateString();
                tbl.Cell(i, 2).Range.Text = c.client.FIO;
                tbl.Cell(i, 3).Range.Text = countSum.ToString();
                tbl.Cell(i, 4).Range.Text = $"{costSum}";
                tbl.Cell(i, 5).Range.Text = $"{countSum * costSum}";
                itogSumm += (countSum * costSum);

                i++;

                countSum = 0; costSum = 0;
            }
            tbl.Range.Font.Size = 12;
            tbl.Columns.PreferredWidthType = Word.WdPreferredWidthType.wdPreferredWidthAuto;
            document.Paragraphs.Add();
            pText.Format.SpaceAfter = 10f;
            pText.Format.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
            pText.Range.Text = $"Итого {itogSumm}";
            pText.Range.InsertParagraphAfter();
            application.Visible = true;
        }

        private void btnOtchtExcel_Click(object sender, RoutedEventArgs e)
        {
            if (d.Count == 0)
            {
                MessageBox.Show("Получите данные");
                return;
            }

            var application = new Excel.Application();
            application.SheetsInNewWorkbook = 1;

            Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet = application.Worksheets[1];
            worksheet.Name = "Лист1";

            worksheet.Cells[1][1] = $"Отчет по продажам за период от {dtpStart.SelectedDate.Value.Date.ToString().Substring(0, 10)} до {dtpEnd.SelectedDate.Value.Date.ToString().Substring(0, 10)}";

            Excel.Range table = worksheet.Range[worksheet.Cells[1][3], worksheet.Cells[5][d.Count + 3]];
            table.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            table.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;

            table.Cells[1][1] = "Дата продажи";
            table.Cells[2][1] = "Клиент";
            table.Cells[3][1] = "Количество";
            table.Cells[4][1] = "Цена";
            table.Cells[5][1] = "Сумма";

            int i = 2;
            double countSum = 0; double costSum = 0; double itogSumm = 0;
            foreach (var c in d)
            {
                foreach (var t in c.telephones)
                {
                    countSum += t.count;
                    costSum += t.cost;
                }
                table.Cells[1][i] = c.dateSale.Date;
                table.Cells[2][i] = c.client.FIO;
                table.Cells[3][i] = countSum;
                table.Cells[4][i] = costSum;
                table.Cells[5][i].Formula = $"=C{i + 2} * D{i + 2}";

                itogSumm += countSum * costSum;

                i++;
                countSum = 0;
                costSum = 0;
            }

            table.Columns.AutoFit();

            worksheet.Cells[4][i + 2] = "Итого";
            worksheet.Cells[5][i + 2].Formula = $"=SUM(E4:E{i + 1})";

            application.Visible = true;
        }

        private void cmbSelectDiagr_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            try
            {
                if (cmbSelectDiagr.SelectedIndex == 0)
                {
                    PiePlot.Visibility = Visibility.Visible;
                    LinePlot.Visibility = Visibility.Collapsed;
                    PiePlot.Reset();
                    LinePlot.Reset();

                    double[] valuesPie = data.Values.ToArray();

                    var pie = PiePlot.plt.AddPie(valuesPie);
                    pie.SliceLabels = data.Keys.ToArray();
                    pie.ShowPercentages = true;
                    pie.ShowValues = true;
                    pie.ShowLabels = true;
                    PiePlot.plt.Legend();
                    PiePlot.Refresh();
                }

                else if (cmbSelectDiagr.SelectedIndex == 1)
                {
                    LinePlot.Visibility = Visibility.Visible;
                    PiePlot.Visibility = Visibility.Collapsed;
                    PiePlot.Reset();
                    LinePlot.Reset();

                    if (d.GroupBy(r => r.dateSale).Select(s => s.Key).Count() < 2) return;

                    LinePlot.Visibility = Visibility.Visible;
                    List<double> valuesLine = new List<double>();
                    List<DateTime> dates = new List<DateTime>();
                    foreach (DateTime date in d.GroupBy(r => r.dateSale).Select(s => s.Key))
                    {
                        List<Telephone> telephone = GetTelephones(d.Where(r => r.dateSale == date).ToList());
                        valuesLine.Add(telephone.Select(t => (double)t.cost * t.count).Sum());
                        dates.Add(date);
                    }
                    double[] xs = dates.Select(x => x.ToOADate()).ToArray();
                    LinePlot.Plot.AddScatter(xs, valuesLine.ToArray());
                    LinePlot.Plot.XAxis.DateTimeFormat(true);
                    List<double> yPositions = new List<double>();
                    List<string> yLabels = new List<string>();
                    for (int i = 0; i <= Math.Round(valuesLine.Max()); i += (int)Math.Floor(Math.Round(valuesLine.Max()) - Math.Round(valuesLine.Min())) / 17)
                    {
                        yPositions.Add(i);
                        yLabels.Add(i.ToString());
                    }
                    yPositions.Add(Math.Floor(valuesLine.Max()));
                    yLabels.Add(Math.Floor(valuesLine.Max()).ToString());
                    yPositions[1] = Math.Floor(valuesLine.Min());
                    yLabels[1] = Math.Floor(valuesLine.Min()).ToString();
                    yPositions[2] = Math.Floor((yPositions[1] + yPositions[3]) / 2);
                    yLabels[2] = Math.Floor((yPositions[1] + yPositions[3]) / 2).ToString();
                    yPositions[18] = Math.Floor((yPositions[16] + yPositions[18]) / 2);
                    yLabels[18] = Math.Floor((yPositions[16] + yPositions[18]) / 2).ToString();

                    LinePlot.Refresh();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private List<Telephone> GetTelephones(List<Sale> sales)
        {
            List<Telephone> telephoness = new List<Telephone>();
            foreach (Sale s in sales)
            {
                telephoness.AddRange(s.telephones);
            }
            return telephoness;
        }
        public string GenerActCode()
        {
            Random rand = new Random();
            string actCode = "";
            char tmpS;
            int tmpN;
            int rW;
            for (int i = 0; i < 10; i++)
            {
                rW = rand.Next(1, 101);
                if (rW % 2 == 0)
                {
                    tmpS = (char)rand.Next('A', 'Z' + 1);
                    actCode += tmpS.ToString();
                }
                else
                {
                    tmpN = rand.Next(0, 10);
                    actCode += tmpN.ToString();
                }
            }

            return actCode;
        }
    }
}
